
//Chap 43
//Placing scripts
alert("Hello from Separate JS file");