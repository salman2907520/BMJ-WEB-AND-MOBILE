function popup(message) {
    alert("Hello "+message);
    alert("New "+message);
}