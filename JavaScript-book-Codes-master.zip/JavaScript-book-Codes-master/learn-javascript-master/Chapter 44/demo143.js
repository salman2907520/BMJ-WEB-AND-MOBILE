
//Chap 44
//Commenting

// This function takes two argument and return their sum
function sum(a,b){
    return a + b;
}

var total = sum(4,5); 
alert(total);

/*
function add(x,y){
    return x + y;
}
*/